var Languages = {
	en: {info: 'Page <no> of <total>', prev: 'Previous Story', next: 'Next Story'},
	fr: {info: 'Page <no> de <total>', prev: 'Article Précédent', next: 'Article Suivant'},
	de: {info: 'Seite <no> von <total>', prev: 'Vorheriger Artikel', next: 'Nächster Artikel'},
	it: {info: 'Pagina <no> di <total>', prev: 'Storia precedente', next: 'Storia successiva'}
}